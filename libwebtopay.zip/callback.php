<?php

require_once('WebToPay.php');
//$params = [];
//parse_str(base64_decode(strtr($_GET['data'], ['-' => '+', '_' => '/'])), $params);
//file_put_contents('request-max.txt',var_export($params,true));
//file_put_contents('request-max2.txt',$params);
function isPaymentValid(array $order, array $response): bool
{
    if (array_key_exists('payamount', $response) === false) {
        if ($order['amount'] !== $response['amount'] || $order['currency'] !== $response['currency']) {
            throw new Exception('Wrong payment amount');
        }
    } else {
        if ($order['amount'] !== $response['payamount'] || $order['currency'] !== $response['paycurrency']) {
            throw new Exception('Wrong payment amount');
        }
    }

    return true;
}

try {
    $response = WebToPay::validateAndParseData(
        $_REQUEST,
        '249340',
        'add08f927c0dec3bdf1f6d3af8db187e'
    );
//file_put_contents('resp-info.txt',$response);

    if ($response['status'] === '1') {
        //@ToDo: Validate payment amount and currency, example provided in isPaymentValid method.
        //@ToDo: Validate order status by $response['orderid']. If it is not already approved, approve it.
        ////
        require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php' );
        $email = get_option('admin_email');
        $subject = 'Новая оплата с сайта';
        $summa = (int)$response['payamount']/100;
        $message = 'Получена новая оплата:' .
            '<br>Заказ: ' . $response['orderid'].
            '<br>Сумма: ' . $summa ;
        wp_mail($email, $subject, $message);

        ////
        echo 'OK';
    } else {
        throw new Exception('Payment was not successful');
    }
} catch (Exception $exception) {
    echo get_class($exception) . ':' . $exception->getMessage();
}
