<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
    <title></title>
</head>
<body>
<div style="    text-align: center;
    padding-top: 10%;">
    Mokėjimas buvo atšauktas Jūsų pačių iniciatyva.<br>
    Jei tai įvyko netyčia, kviečiame bandyti dar kartą.



    <br>
    <br>
    <a href="https://koradius-travel.com/">koradius-travel.com</a>
</div>
</body>
</html>
