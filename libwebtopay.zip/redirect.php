<?php

require_once('WebToPay.php');
$price = 0;
$order_id = 0;
if (isset($_GET['price']) && $_GET['price'] !== ''){
    $price = $_GET['price'];
}
if (isset($_GET['order_id']) && $_GET['order_id'] !== ''){
    $order_id = $_GET['order_id'];
}
function getSelfUrl(): string
{
    $url = substr(strtolower($_SERVER['SERVER_PROTOCOL']), 0, strpos($_SERVER['SERVER_PROTOCOL'], '/'));

    if (isset($_SERVER['HTTPS']) === true) {
        $url .= ($_SERVER['HTTPS'] === 'on') ? 's' : '';
    }

    $url .= '://' . $_SERVER['HTTP_HOST'];

    if (isset($_SERVER['SERVER_PORT']) === true && $_SERVER['SERVER_PORT'] !== '80') {
        $url .= ':' . $_SERVER['SERVER_PORT'];
    }

    $url .= dirname($_SERVER['SCRIPT_NAME']);

    return $url;
}

try {
    WebToPay::redirectToPayment([
        'projectid' => '249340',
        'sign_password' => 'add08f927c0dec3bdf1f6d3af8db187e',
        'orderid' => $order_id,
        'amount' => $price*100,
        'currency' => 'EUR',
        'country' => 'LT',
        'accepturl' => getSelfUrl() . '/accept.php',
        'cancelurl' => getSelfUrl() . '/cancel.php',
        'callbackurl' => getSelfUrl() . '/callback.php',
        'test' => 0,
    ]);
} catch (Exception $exception) {
    echo get_class($exception) . ':' . $exception->getMessage();
}
